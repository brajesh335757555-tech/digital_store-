# VPS Selling Demo

Simple Flask + SQLite VPS plan selling demo.

## Run locally

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/VPS:
source .venv/bin/activate

pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`

## Demo admin

Username: `admin`  
Password: `admin123`

Change the password and `app.secret_key` before any real deployment.

This project intentionally uses a demo order flow. Connect a legitimate payment gateway using its official API and keep all API secrets in environment variables, never in GitHub.
