from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3
from functools import wraps

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
DB = "vps_store.db"

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = db()
    con.execute("""CREATE TABLE IF NOT EXISTS plans(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        specs TEXT NOT NULL,
        price INTEGER NOT NULL,
        stock INTEGER NOT NULL DEFAULT 0
    )""")
    con.execute("""CREATE TABLE IF NOT EXISTS orders(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer TEXT NOT NULL,
        plan_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        total INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'Pending'
    )""")
    if con.execute("SELECT COUNT(*) FROM plans").fetchone()[0] == 0:
        con.executemany(
            "INSERT INTO plans(name,specs,price,stock) VALUES(?,?,?,?)",
            [
                ("Starter VPS", "2 Core • 4 GB RAM • 50 GB SSD", 299, 10),
                ("Business VPS", "4 Core • 8 GB RAM • 100 GB SSD", 599, 8),
                ("Pro VPS", "8 Core • 16 GB RAM • 200 GB SSD", 999, 5),
            ],
        )
    con.commit()
    con.close()

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("admin"):
            return redirect(url_for("admin_login"))
        return fn(*args, **kwargs)
    return wrapper

@app.route("/")
def index():
    con = db()
    plans = con.execute("SELECT * FROM plans").fetchall()
    con.close()
    return render_template("index.html", plans=plans)

@app.route("/order/<int:plan_id>", methods=["GET","POST"])
def order(plan_id):
    con = db()
    plan = con.execute("SELECT * FROM plans WHERE id=?", (plan_id,)).fetchone()
    if not plan:
        con.close()
        return "Plan not found", 404
    if request.method == "POST":
        customer = request.form.get("customer","").strip()
        qty = max(1, int(request.form.get("quantity",1)))
        if not customer or qty > plan["stock"]:
            con.close()
            return "Invalid customer or insufficient stock", 400
        total = qty * plan["price"]
        con.execute("INSERT INTO orders(customer,plan_id,quantity,total) VALUES(?,?,?,?)",
                    (customer, plan_id, qty, total))
        con.execute("UPDATE plans SET stock=stock-? WHERE id=?", (qty, plan_id))
        con.commit()
        con.close()
        return render_template("success.html", customer=customer, total=total)
    con.close()
    return render_template("order.html", plan=plan)

@app.route("/admin/login", methods=["GET","POST"])
def admin_login():
    if request.method == "POST":
        if request.form.get("username") == "admin" and request.form.get("password") == "admin123":
            session["admin"] = True
            return redirect(url_for("admin"))
        return render_template("admin_login.html", error="Invalid login")
    return render_template("admin_login.html")

@app.route("/admin")
@admin_required
def admin():
    con = db()
    plans = con.execute("SELECT * FROM plans").fetchall()
    orders = con.execute("""SELECT orders.*, plans.name AS plan_name
                           FROM orders JOIN plans ON orders.plan_id=plans.id
                           ORDER BY orders.id DESC""").fetchall()
    con.close()
    return render_template("admin.html", plans=plans, orders=orders)

@app.route("/admin/plan", methods=["POST"])
@admin_required
def add_plan():
    con = db()
    con.execute("INSERT INTO plans(name,specs,price,stock) VALUES(?,?,?,?)",
                (request.form["name"], request.form["specs"],
                 int(request.form["price"]), int(request.form["stock"])))
    con.commit()
    con.close()
    return redirect(url_for("admin"))

@app.route("/admin/order/<int:order_id>/<status>")
@admin_required
def order_status(order_id, status):
    if status not in {"Pending","Paid","Completed","Cancelled"}:
        return "Invalid status", 400
    con = db()
    con.execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))
    con.commit()
    con.close()
    return redirect(url_for("admin"))

@app.route("/admin/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)
